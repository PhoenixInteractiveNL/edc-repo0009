# Changelog
tag 0.6
Tagger: Fred Klaus <development@fkweb.de>

This is the first version build with c++11 enabled comiler

Sat Apr 9 18:12:56 2016 +0200 
[view tag](https://github.com/raldus/roland/commit/0f6a55a7cd2583c3026b57c94a036062b44d3df1) 

***
