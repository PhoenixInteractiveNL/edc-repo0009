tag 0.6
Tagger: Fred Klaus <development@fkweb.de>

This is the first version build with c++11 enabled comiler

Sat Apr 9 18:12:56 2016 +0200 
[view tag](https://github.com/raldus/roland/commit/0f6a55a7cd2583c3026b57c94a036062b44d3df1) 

***

tag 0.61
Tagger: Fred Klaus <development@fkweb.de>

Builds on VS2015 32bit now

Wed Nov 30 21:24:04 2016 +0100 
[view tag](https://github.com/raldus/roland/commit/8dc859b4838b1a4339a0a6c5af0e039ad11d83c6) 

***

tag 0.62
Tagger: Fred Klaus <development@fkweb.de>

Clean build of roland

Mon Dec 5 19:42:33 2016 +0100 
[view tag](https://github.com/raldus/roland/commit/bae93065f81f1ce7e155f2d1bfeb04237c047e9d) 

***
