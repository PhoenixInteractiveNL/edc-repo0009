tag 0.6
Tagger: Fred Klaus <development@fkweb.de>

This is the first version build with c++11 enabled comiler

Sat Apr 9 18:12:56 2016 +0200 
[view tag](https://github.com/raldus/roland/commit/0f6a55a7cd2583c3026b57c94a036062b44d3df1) 

***

tag 0.61
Tagger: Fred Klaus <development@fkweb.de>

Builds on VS2015 32bit now

Wed Nov 30 21:24:04 2016 +0100 
[view tag](https://github.com/raldus/roland/commit/8dc859b4838b1a4339a0a6c5af0e039ad11d83c6) 

***

tag 0.62
Tagger: Fred Klaus <development@fkweb.de>

Clean build of roland

Mon Dec 5 19:42:33 2016 +0100 
[view tag](https://github.com/raldus/roland/commit/bae93065f81f1ce7e155f2d1bfeb04237c047e9d) 

***

tag 0.63
Tagger: Fred Klaus <development@fkweb.de>

GUI improvement

Thu Dec 8 23:30:18 2016 +0100 
[view tag](https://github.com/raldus/roland/commit/e9f157b312ec4a0e72c5885c630720c6963340f4) 

***

tag 0.64
Tagger: Fred Klaus <development@fkweb.de>

Bugfix release

Sat Mar 25 19:18:53 2017 +0100 
[view tag](https://github.com/raldus/roland/commit/1402c13da0e33776228a89cb9e5b43b93478aa6f) 

***

tag 0.65
Tagger: Fred Klaus <development@fkweb.de>

bufix release

Sat Mar 25 19:48:56 2017 +0100 
[view tag](https://github.com/raldus/roland/commit/498342a43c7a0251b6c3456a685c93b0c5a3e4e8) 

***

tag 0.66
Tagger: Fred Klaus <development@fkweb.de>

New bugfix release. Handles deb packages

Sun Mar 26 20:13:53 2017 +0200 
[view tag](https://github.com/raldus/roland/commit/540e49668daed539ee0a2ab013b0a126919cd259) 

***
