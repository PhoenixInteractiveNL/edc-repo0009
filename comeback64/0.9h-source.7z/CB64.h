// ### DEFINES ##############################################################
#define PAL

// ### EXTERN VARIABLES #####################################################
extern unsigned char soundblasterversion;
extern unsigned char SIDRegs[0x1c];
extern unsigned char far *RAMPointer;
extern unsigned long cyc_orig;
extern unsigned long cyc_last;
extern unsigned long cycles;
extern int percent,skipper;
extern unsigned char interlaced;
