/*
HARDSID INFO:

Address: 0xD400-0xD41C
54272d-54300d
*/

/*~~~~~~DRIVER BY JOHAN FITIE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

// ### HARDSIDWRITE #########################################################
void hardsidwrite (unsigned char data, unsigned int address, unsigned int HARDSID)
{
        outportb (HARDSID,data);
        outportb (HARDSID+1,address&0x1F);
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        }

// ### HARDSIDREAD #########################################################
unsigned char hardsidread (unsigned int address, unsigned int HARDSID)
{
        unsigned char result;
        outportb (HARDSID+1,(address&0x1F)|0x20);
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        _asm {
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                nop;
                }
        result=inportb (HARDSID);
        return (result);
        }

