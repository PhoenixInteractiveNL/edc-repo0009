// ### DEFINES ##############################################################
#define SB_DETECT	0
#define SB_8BIT		1
#define SB_PRO		3
#define SB_16		4

// ### ROUTINES #############################################################
int SBInit(int);
void SBClose(void);
static int SBGetVer(void);

