// ### EXTERN VARIABLES #####################################################
extern unsigned long DMAbufsize;
extern void far *DMAbufptr,*DMAbufptr2;
extern unsigned long DMAbufadr, DMAbufadr2;

// ### VARIABLES ############################################################
int DMAAutoInit(int,unsigned long);
int DMASingleInit(int,unsigned long);

// ### ROUTINES #############################################################
void DMASingleGo(int);

